/**
 * NAILAURA BY ABHA — CORE APPLICATION LOGIC
 * High-End Luxury Press-On Nail E-Commerce System
 */

(function () {
  'use strict';

  // --- Product Catalog Data ---
  const PRODUCTS = [
    {
      id: 'blush-french-elegance',
      name: 'Blush French Elegance',
      category: 'french-tips',
      categoryLabel: 'French Tips',
      price: 1299,
      rating: 5.0,
      reviewsCount: 38,
      badge: 'bestseller',
      badgeText: 'Best Seller',
      image: 'assets/images/prod_blush_french_hd.png',
      gallery: [
        'assets/images/prod_blush_french_hd.png',
        'assets/images/hero_nails_hd.png',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'Soft blush tones meet classic French tips in a design that feels effortlessly elegant. Perfect for brunch dates, celebrations, or adding a polished touch to your everyday look.',
      shapes: ['Almond', 'Oval', 'Coffin', 'Square'],
      finishes: ['Glossy', 'Matte'],
      defaultShape: 'Almond',
      defaultFinish: 'Glossy',
      tags: ['french-tips', 'minimal-nude', 'best-sellers']
    },
    {
      id: 'blush-dream',
      name: 'Blush Dream',
      category: 'minimal-nude',
      categoryLabel: 'Minimal & Nude',
      price: 1299,
      rating: 4.9,
      reviewsCount: 42,
      badge: 'bestseller',
      badgeText: 'Best Seller',
      image: 'assets/images/prod_blush_dream_hd.png',
      gallery: [
        'assets/images/prod_blush_dream_hd.png',
        'assets/images/cat_everyday_hd.png',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'Understated luxury with delicate milky blush tones and a glass-like sheen that complements every skin tone.',
      shapes: ['Almond', 'Oval', 'Square'],
      finishes: ['Glossy'],
      defaultShape: 'Almond',
      defaultFinish: 'Glossy',
      tags: ['minimal-nude', 'everyday-elegance', 'best-sellers']
    },
    {
      id: 'lavender-bloom',
      name: 'Lavender Bloom',
      category: 'floral-artistic',
      categoryLabel: 'Floral & Artistic',
      price: 1349,
      rating: 5.0,
      reviewsCount: 29,
      badge: 'new',
      badgeText: 'New Arrival',
      image: 'assets/images/prod_lavender_bloom_hd.png',
      gallery: [
        'assets/images/prod_lavender_bloom_hd.png',
        'assets/images/prod_lavender_art.jpg',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'Hand-painted delicate botanical florals and soft lilac hues with micro-pearl accents for an ethereal aura.',
      shapes: ['Almond', 'Coffin', 'Stiletto'],
      finishes: ['Glossy', 'Matte'],
      defaultShape: 'Almond',
      defaultFinish: 'Glossy',
      tags: ['floral-artistic', 'new-arrivals']
    },
    {
      id: 'golden-hour',
      name: 'Golden Hour',
      category: 'glitter-glam',
      categoryLabel: 'Glitter & Glam',
      price: 1399,
      rating: 4.9,
      reviewsCount: 54,
      badge: 'bestseller',
      badgeText: 'Trending',
      image: 'assets/images/prod_golden_hour_hd.png',
      gallery: [
        'assets/images/prod_golden_hour_hd.png',
        'assets/images/prod_golden_chrome.jpg',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'Capturing sunset radiance with fine spun champagne shimmer, gilded leaf edges, and multifaceted sparkle.',
      shapes: ['Almond', 'Coffin', 'Stiletto'],
      finishes: ['Glossy'],
      defaultShape: 'Coffin',
      defaultFinish: 'Glossy',
      tags: ['glitter-glam', 'special-occasions', 'best-sellers']
    },
    {
      id: 'wild-hearts',
      name: 'Wild Hearts',
      category: 'floral-artistic',
      categoryLabel: 'Artisan Nail Art',
      price: 1299,
      rating: 4.8,
      reviewsCount: 31,
      badge: 'trending',
      badgeText: 'Trending',
      image: 'assets/images/prod_wild_hearts_hd.png',
      gallery: [
        'assets/images/prod_wild_hearts_hd.png',
        'assets/images/prod_wild_art.jpg',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'Contrasting moody noir accents with romantic hand-drawn micro heart motifs for effortless edgy charm.',
      shapes: ['Almond', 'Square', 'Coffin'],
      finishes: ['Glossy', 'Matte'],
      defaultShape: 'Almond',
      defaultFinish: 'Glossy',
      tags: ['floral-artistic', 'artisan-nail-art']
    },
    {
      id: 'rose-quartz-shimmer',
      name: 'Rose Quartz Shimmer',
      category: 'glitter-glam',
      categoryLabel: 'Glitter & Glam',
      price: 1449,
      rating: 5.0,
      reviewsCount: 26,
      badge: 'new',
      badgeText: 'New Arrival',
      image: 'assets/images/prod_rose_quartz.jpg',
      gallery: [
        'assets/images/prod_rose_quartz.jpg',
        'assets/images/hero_nails_hd.png',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'Inspired by healing rose quartz crystals with delicate marble veins and fine iridescent golden glitter.',
      shapes: ['Almond', 'Coffin', 'Oval'],
      finishes: ['Glossy'],
      defaultShape: 'Almond',
      defaultFinish: 'Glossy',
      tags: ['glitter-glam', 'new-arrivals', 'special-occasions']
    },
    {
      id: 'velvet-mocha-chrome',
      name: 'Velvet Mocha Chrome',
      category: 'minimal-nude',
      categoryLabel: 'Minimal & Nude',
      price: 1399,
      rating: 4.9,
      reviewsCount: 37,
      badge: null,
      badgeText: null,
      image: 'assets/images/prod_velvet_mocha.jpg',
      gallery: [
        'assets/images/prod_velvet_mocha.jpg',
        'assets/images/cat_everyday_hd.png',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'Ultra-luxurious rich espresso and warm caramel chrome with a deep magnetic optical luster.',
      shapes: ['Almond', 'Square', 'Coffin'],
      finishes: ['Glossy'],
      defaultShape: 'Square',
      defaultFinish: 'Glossy',
      tags: ['minimal-nude', 'everyday-elegance']
    },
    {
      id: 'ivory-pearl-glaze',
      name: 'Ivory Pearl Glaze',
      category: 'bridal-occasion',
      categoryLabel: 'Bridal & Occasion',
      price: 1499,
      rating: 5.0,
      reviewsCount: 48,
      badge: 'bestseller',
      badgeText: 'Bridal Pick',
      image: 'assets/images/prod_pearl_bridal.jpg',
      gallery: [
        'assets/images/prod_pearl_bridal.jpg',
        'assets/images/top_hands_hd.png',
        'assets/images/packaging_box_hd.png'
      ],
      description: 'The pinnacle of bridal opulence: sheer glazed doughnut finish, hand-set Austrian micro-pearls, and soft aura contours.',
      shapes: ['Almond', 'Oval', 'Coffin'],
      finishes: ['Glossy'],
      defaultShape: 'Almond',
      defaultFinish: 'Glossy',
      tags: ['bridal-occasion', 'special-occasions', 'best-sellers']
    }
  ];

  // --- Application State ---
  const state = {
    cart: JSON.parse(localStorage.getItem('nailaura_cart') || '[]'),
    wishlist: JSON.parse(localStorage.getItem('nailaura_wishlist') || '[]'),
    activeFilter: 'all',
    searchQuery: '',
    sortBy: 'featured',
    appliedCoupon: localStorage.getItem('nailaura_coupon') || null,
    freeShippingThreshold: 1999,
    shippingFee: 149
  };

  // Helper to save state
  function saveCart() {
    localStorage.setItem('nailaura_cart', JSON.stringify(state.cart));
    updateHeaderCounters();
    renderCartDrawer();
  }

  function saveWishlist() {
    localStorage.setItem('nailaura_wishlist', JSON.stringify(state.wishlist));
    updateHeaderCounters();
    renderWishlistDrawer();
    updateWishlistCardIcons();
  }

  // --- Toast Notification System ---
  function showToast(message, icon = '✨') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  // --- Header Counters ---
  function updateHeaderCounters() {
    const cartCountEl = document.getElementById('cartBadgeCount');
    const wishlistCountEl = document.getElementById('wishlistBadgeCount');

    const totalCartItems = state.cart.reduce((sum, item) => sum + item.quantity, 0);
    if (cartCountEl) {
      cartCountEl.textContent = totalCartItems;
      cartCountEl.style.display = totalCartItems > 0 ? 'flex' : 'none';
    }

    if (wishlistCountEl) {
      wishlistCountEl.textContent = state.wishlist.length;
      wishlistCountEl.style.display = state.wishlist.length > 0 ? 'flex' : 'none';
    }
  }

  // --- Format Indian Currency (INR) ---
  function formatINR(amount) {
    return '₹' + amount.toLocaleString('en-IN');
  }

  // --- Render Product Catalog ---
  function renderProductsGrid() {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;

    let filtered = PRODUCTS.filter(p => {
      // Filter tab check
      if (state.activeFilter === 'all') return true;
      if (state.activeFilter === 'new-arrivals') return p.tags.includes('new-arrivals');
      if (state.activeFilter === 'best-sellers') return p.tags.includes('best-sellers');
      if (state.activeFilter === 'minimal-nude') return p.tags.includes('minimal-nude');
      if (state.activeFilter === 'french-tips') return p.tags.includes('french-tips');
      if (state.activeFilter === 'floral-artistic') return p.tags.includes('floral-artistic');
      if (state.activeFilter === 'glitter-glam') return p.tags.includes('glitter-glam');
      if (state.activeFilter === 'bridal-occasion') return p.tags.includes('bridal-occasion') || p.tags.includes('special-occasions');
      return p.category === state.activeFilter;
    });

    // Search query check
    if (state.searchQuery.trim()) {
      const q = state.searchQuery.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.categoryLabel.toLowerCase().includes(q)
      );
    }

    // Sort check
    if (state.sortBy === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (state.sortBy === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    } else if (state.sortBy === 'rating') {
      filtered.sort((a, b) => b.rating - a.rating);
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem;">
          <p style="font-family: var(--font-serif); font-size: 1.4rem; color: var(--color-charcoal); margin-bottom: 0.5rem;">No designs found</p>
          <p style="color: var(--color-charcoal-muted); font-size: 0.95rem;">Try adjusting your filter or search query to find your dream aura set.</p>
          <button class="btn btn-primary btn-sm" style="margin-top: 1.5rem;" onclick="window.NailAuraApp.resetFilters()">View All Designs</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(product => {
      const isWishlisted = state.wishlist.includes(product.id);
      const badgeHtml = product.badge ? `
        <span class="product-badge badge-${product.badge}">
          ${product.badgeText}
        </span>
      ` : '';

      return `
        <article class="product-card" data-product-id="${product.id}">
          <div class="product-thumb-box">
            ${badgeHtml}
            <button class="btn-wishlist ${isWishlisted ? 'active' : ''}"
                    aria-label="Save to Wishlist"
                    onclick="window.NailAuraApp.toggleWishlist('${product.id}')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="${isWishlisted ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
              </svg>
            </button>
            <img src="${product.image}" alt="${product.name} — Handcrafted press-on nail art by NailAura" loading="lazy">
            <div class="quick-view-overlay">
              <button class="btn-quick-view" onclick="window.NailAuraApp.openQuickView('${product.id}')">
                Quick View
              </button>
            </div>
          </div>
          <div class="product-info">
            <span class="product-category-tag">${product.categoryLabel}</span>
            <h3 class="product-name">${product.name}</h3>
            <div class="product-rating">
              <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
              <span class="review-count">(${product.reviewsCount})</span>
            </div>
            <div class="product-footer-row">
              <span class="product-price">${formatINR(product.price)}</span>
              <button class="btn-add-cart-icon"
                      aria-label="Add ${product.name} to Cart"
                      onclick="window.NailAuraApp.quickAddToCart('${product.id}')"
                      title="Quick Add to Bag">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                  <line x1="3" y1="6" x2="21" y2="6"></line>
                  <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
              </button>
            </div>
          </div>
        </article>
      `;
    }).join('');
  }

  // Update wishlist heart state on product cards
  function updateWishlistCardIcons() {
    document.querySelectorAll('.product-card').forEach(card => {
      const pid = card.getAttribute('data-product-id');
      const btn = card.querySelector('.btn-wishlist');
      if (btn && pid) {
        const isWish = state.wishlist.includes(pid);
        btn.classList.toggle('active', isWish);
        const svg = btn.querySelector('svg');
        if (svg) {
          svg.setAttribute('fill', isWish ? 'currentColor' : 'none');
        }
      }
    });
  }

  // --- Cart Drawer System ---
  function openCartDrawer() {
    const backdrop = document.getElementById('drawerBackdrop');
    const drawer = document.getElementById('cartDrawer');
    if (backdrop && drawer) {
      backdrop.classList.add('active');
      drawer.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeDrawers() {
    const backdrop = document.getElementById('drawerBackdrop');
    const cartDrawer = document.getElementById('cartDrawer');
    const wishlistDrawer = document.getElementById('wishlistDrawer');
    const mobileDrawer = document.getElementById('mobileNavDrawer');
    if (backdrop) backdrop.classList.remove('active');
    if (cartDrawer) cartDrawer.classList.remove('open');
    if (wishlistDrawer) wishlistDrawer.classList.remove('open');
    if (mobileDrawer) mobileDrawer.classList.remove('open');
    document.body.style.overflow = '';
  }

  function openMobileMenu() {
    const backdrop = document.getElementById('drawerBackdrop');
    const mobileDrawer = document.getElementById('mobileNavDrawer');
    if (backdrop && mobileDrawer) {
      closeDrawers();
      backdrop.classList.add('active');
      mobileDrawer.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeMobileMenu() {
    closeDrawers();
  }

  function renderCartDrawer() {
    const body = document.getElementById('cartDrawerBody');
    const footer = document.getElementById('cartDrawerFooter');
    const progressBanner = document.getElementById('shippingProgressBanner');
    if (!body || !footer) return;

    if (state.cart.length === 0) {
      body.innerHTML = `
        <div class="drawer-empty-state">
          <div class="drawer-empty-icon">✨</div>
          <h4 class="drawer-empty-title">Your Bag is Empty</h4>
          <p class="drawer-empty-desc">Discover our handcrafted sets made to reflect your aura and individuality.</p>
          <button class="btn btn-primary btn-sm" onclick="window.NailAuraApp.closeDrawers(); location.href='#shop';">
            Explore Collection
          </button>
        </div>
      `;
      footer.style.display = 'none';
      if (progressBanner) progressBanner.style.display = 'none';
      return;
    }

    footer.style.display = 'flex';
    if (progressBanner) progressBanner.style.display = 'block';

    // Calculate subtotal
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const freeShipping = subtotal >= state.freeShippingThreshold;
    const amountAway = state.freeShippingThreshold - subtotal;
    const progressPercent = Math.min(100, (subtotal / state.freeShippingThreshold) * 100);

    // Update Shipping Progress Banner
    if (progressBanner) {
      const bannerText = progressBanner.querySelector('.progress-text');
      const bannerBar = progressBanner.querySelector('.progress-bar-fill');
      if (bannerText && bannerBar) {
        if (freeShipping) {
          bannerText.innerHTML = `✨ <strong>Congratulations!</strong> You qualify for <strong>FREE Pan-India Express Delivery</strong>!`;
          bannerBar.style.width = '100%';
        } else {
          bannerText.innerHTML = `Add <strong>${formatINR(amountAway)}</strong> more for <strong>FREE Pan-India Delivery</strong>!`;
          bannerBar.style.width = `${progressPercent}%`;
        }
      }
    }

    // Render items
    body.innerHTML = state.cart.map((item, index) => `
      <div class="cart-item-card" data-index="${index}">
        <div class="cart-item-img">
          <img src="${item.image}" alt="${item.name}">
        </div>
        <div class="cart-item-info">
          <h5 class="cart-item-title">${item.name}</h5>
          <p class="cart-item-specs">Shape: ${item.shape} • Size: ${item.size} • Finish: ${item.finish}</p>
          <div class="cart-item-price-row">
            <span class="cart-item-price">${formatINR(item.price * item.quantity)}</span>
            <div class="quantity-stepper" style="transform: scale(0.85); transform-origin: right center;">
              <button class="stepper-btn" onclick="window.NailAuraApp.updateCartQty(${index}, -1)">−</button>
              <span class="stepper-input">${item.quantity}</span>
              <button class="stepper-btn" onclick="window.NailAuraApp.updateCartQty(${index}, 1)">+</button>
            </div>
            <button class="cart-item-remove" onclick="window.NailAuraApp.removeCartItem(${index})" title="Remove">✕</button>
          </div>
        </div>
      </div>
    `).join('');

    // Discount calculations
    let discount = 0;
    if (state.appliedCoupon === 'AURA10') {
      discount = Math.round(subtotal * 0.10);
    }

    const shipping = freeShipping ? 0 : state.shippingFee;
    const total = subtotal - discount + shipping;

    // Render footer values
    footer.innerHTML = `
      <div class="coupon-row">
        <input type="text" id="cartCouponInput" placeholder="PROMO CODE (e.g. AURA10)" value="${state.appliedCoupon || ''}">
        <button class="btn btn-secondary btn-sm" onclick="window.NailAuraApp.applyCoupon()">Apply</button>
      </div>
      ${state.appliedCoupon ? `
        <div style="font-size: 0.78rem; color: var(--color-success); display: flex; justify-content: space-between;">
          <span>✓ Coupon '${state.appliedCoupon}' applied (10% OFF)</span>
          <a href="#" style="text-decoration: underline;" onclick="window.NailAuraApp.removeCoupon(); return false;">Remove</a>
        </div>
      ` : ''}
      <div class="cart-summary-row">
        <span>Subtotal</span>
        <span>${formatINR(subtotal)}</span>
      </div>
      ${discount > 0 ? `
        <div class="cart-summary-row" style="color: var(--color-rose-dark);">
          <span>Discount (AURA10)</span>
          <span>−${formatINR(discount)}</span>
        </div>
      ` : ''}
      <div class="cart-summary-row">
        <span>Shipping</span>
        <span>${freeShipping ? '<strong style="color: var(--color-success);">FREE</strong>' : formatINR(shipping)}</span>
      </div>
      <div class="cart-summary-row total-row">
        <span>Estimated Total</span>
        <span style="color: var(--color-rose-dark);">${formatINR(total)}</span>
      </div>
      <button class="btn btn-primary btn-lg" style="width: 100%; margin-top: 0.5rem;" onclick="window.NailAuraApp.openCheckoutModal()">
        Proceed to Checkout →
      </button>
      <p style="font-size: 0.72rem; text-align: center; color: var(--color-charcoal-light);">
        🔒 Secure 256-bit checkout • UPI, Cards & COD Accepted
      </p>
    `;
  }

  // --- Wishlist Drawer System ---
  function openWishlistDrawer() {
    const backdrop = document.getElementById('drawerBackdrop');
    const drawer = document.getElementById('wishlistDrawer');
    if (backdrop && drawer) {
      backdrop.classList.add('active');
      drawer.classList.add('open');
      document.body.style.overflow = 'hidden';
      renderWishlistDrawer();
    }
  }

  function renderWishlistDrawer() {
    const body = document.getElementById('wishlistDrawerBody');
    if (!body) return;

    if (state.wishlist.length === 0) {
      body.innerHTML = `
        <div class="drawer-empty-state">
          <div class="drawer-empty-icon">♡</div>
          <h4 class="drawer-empty-title">Your Wishlist is Empty</h4>
          <p class="drawer-empty-desc">Click the heart icon on any design you adore to save it here for later.</p>
          <button class="btn btn-primary btn-sm" onclick="window.NailAuraApp.closeDrawers(); location.href='#shop';">
            Explore Collection
          </button>
        </div>
      `;
      return;
    }

    const items = PRODUCTS.filter(p => state.wishlist.includes(p.id));
    body.innerHTML = items.map(item => `
      <div class="cart-item-card">
        <div class="cart-item-img">
          <img src="${item.image}" alt="${item.name}">
        </div>
        <div class="cart-item-info">
          <h5 class="cart-item-title">${item.name}</h5>
          <p class="cart-item-specs">${item.categoryLabel}</p>
          <div class="cart-item-price-row">
            <span class="cart-item-price">${formatINR(item.price)}</span>
            <div style="display: flex; gap: 0.5rem;">
              <button class="btn btn-rose btn-sm" onclick="window.NailAuraApp.quickAddToCart('${item.id}')">
                Add to Bag
              </button>
              <button class="cart-item-remove" onclick="window.NailAuraApp.toggleWishlist('${item.id}')" title="Remove">✕</button>
            </div>
          </div>
        </div>
      </div>
    `).join('');
  }

  // --- Interactive Size Guide Calculator ---
  function initSizeCalculator() {
    const inputs = ['sizeThumb', 'sizeIndex', 'sizeMiddle', 'sizeRing', 'sizePinky'];
    inputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', calculateRecommendedSize);
      }
    });
  }

  function calculateRecommendedSize() {
    const thumb = parseFloat(document.getElementById('sizeThumb')?.value) || 0;
    const index = parseFloat(document.getElementById('sizeIndex')?.value) || 0;
    const middle = parseFloat(document.getElementById('sizeMiddle')?.value) || 0;
    const ring = parseFloat(document.getElementById('sizeRing')?.value) || 0;
    const pinky = parseFloat(document.getElementById('sizePinky')?.value) || 0;

    const resultVal = document.getElementById('calcSizeResult');
    const resultDesc = document.getElementById('calcSizeDesc');
    if (!resultVal || !resultDesc) return;

    if (!thumb && !index && !middle && !ring && !pinky) {
      resultVal.textContent = 'Size M';
      resultDesc.textContent = 'Enter your millimeter measurements above for an exact personalized fit.';
      return;
    }

    // Comparison against standard sizes:
    // XS: 14, 11, 12, 10, 8
    // S: 15, 12, 13, 11, 8
    // M: 16, 12, 13, 11, 9
    // L: 17, 13, 14, 12, 10
    if (thumb <= 14 && index <= 11 && middle <= 12) {
      resultVal.textContent = 'Size XS';
      resultDesc.textContent = 'Matches standard Extra-Small set (14mm / 11mm / 12mm / 10mm / 8mm).';
    } else if (thumb <= 15 && index <= 12 && middle <= 13 && pinky <= 8.5) {
      resultVal.textContent = 'Size S';
      resultDesc.textContent = 'Matches standard Small set (15mm / 12mm / 13mm / 11mm / 8mm).';
    } else if (thumb <= 16 && index <= 12.5 && middle <= 13.5 && pinky <= 9.5) {
      resultVal.textContent = 'Size M';
      resultDesc.textContent = 'Matches standard Medium set (16mm / 12mm / 13mm / 11mm / 9mm) — our most popular fit!';
    } else if (thumb <= 18 && index <= 14 && middle <= 15) {
      resultVal.textContent = 'Size L';
      resultDesc.textContent = 'Matches standard Large set (17mm / 13mm / 14mm / 12mm / 10mm).';
    } else {
      resultVal.textContent = 'Custom Sizing';
      resultDesc.textContent = `Your measurements (${thumb}/${index}/${middle}/${ring}/${pinky}mm) are unique! Select "Custom" at checkout and our artist Abha will handcraft your bespoke set.`;
    }
  }

  // --- Featured Product Page / Section Handler ---
  function initFeaturedProductSection() {
    // Option Pills
    document.querySelectorAll('#showcaseShapes .pill-option').forEach(btn => {
      btn.addEventListener('click', function () {
        document.querySelectorAll('#showcaseShapes .pill-option').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const valEl = document.getElementById('selectedShapeVal');
        if (valEl) valEl.textContent = this.getAttribute('data-value');
      });
    });

    document.querySelectorAll('#showcaseLengths .pill-option').forEach(btn => {
      btn.addEventListener('click', function () {
        document.querySelectorAll('#showcaseLengths .pill-option').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const valEl = document.getElementById('selectedLengthVal');
        if (valEl) valEl.textContent = this.getAttribute('data-value');
      });
    });

    document.querySelectorAll('#showcaseSizes .pill-option').forEach(btn => {
      btn.addEventListener('click', function () {
        document.querySelectorAll('#showcaseSizes .pill-option').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const valEl = document.getElementById('selectedSizeVal');
        if (valEl) valEl.textContent = this.getAttribute('data-value');
      });
    });

    document.querySelectorAll('#showcaseFinishes .pill-option').forEach(btn => {
      btn.addEventListener('click', function () {
        document.querySelectorAll('#showcaseFinishes .pill-option').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const valEl = document.getElementById('selectedFinishVal');
        if (valEl) valEl.textContent = this.getAttribute('data-value');
      });
    });

    // Gallery Thumbnails
    document.querySelectorAll('.thumb-item').forEach(thumb => {
      thumb.addEventListener('click', function () {
        document.querySelectorAll('.thumb-item').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        const targetSrc = this.getAttribute('data-src');
        const mainImg = document.getElementById('showcaseMainImage');
        if (mainImg && targetSrc) {
          mainImg.style.opacity = '0.5';
          setTimeout(() => {
            mainImg.src = targetSrc;
            mainImg.style.opacity = '1';
          }, 150);
        }
      });
    });

    // Showcase Add to Cart Button
    const showcaseAddBtn = document.getElementById('showcaseAddToCartBtn');
    if (showcaseAddBtn) {
      showcaseAddBtn.addEventListener('click', function () {
        const shape = document.querySelector('#showcaseShapes .pill-option.active')?.getAttribute('data-value') || 'Almond';
        const length = document.querySelector('#showcaseLengths .pill-option.active')?.getAttribute('data-value') || 'Medium';
        const size = document.querySelector('#showcaseSizes .pill-option.active')?.getAttribute('data-value') || 'M';
        const finish = document.querySelector('#showcaseFinishes .pill-option.active')?.getAttribute('data-value') || 'Glossy';
        const qty = parseInt(document.getElementById('showcaseQtyInput')?.value || '1', 10);

        const prod = PRODUCTS.find(p => p.id === 'blush-french-elegance');
        if (!prod) return;

        addToCart({
          id: prod.id,
          name: prod.name,
          price: prod.price,
          image: prod.image,
          shape: `${shape} (${length})`,
          size: size,
          finish: finish,
          quantity: qty
        });

        showToast(`Added ${prod.name} to your bag!`);
        openCartDrawer();
      });
    }

    // Steppers for Showcase Quantity
    const qtyInput = document.getElementById('showcaseQtyInput');
    const minusBtn = document.getElementById('showcaseQtyMinus');
    const plusBtn = document.getElementById('showcaseQtyPlus');

    if (minusBtn && qtyInput) {
      minusBtn.addEventListener('click', () => {
        let val = parseInt(qtyInput.value, 10) || 1;
        if (val > 1) qtyInput.value = val - 1;
      });
    }
    if (plusBtn && qtyInput) {
      plusBtn.addEventListener('click', () => {
        let val = parseInt(qtyInput.value, 10) || 1;
        if (val < 10) qtyInput.value = val + 1;
      });
    }
  }

  // --- Accordion Generic System ---
  function initAccordions() {
    document.querySelectorAll('.accordion-trigger').forEach(trigger => {
      trigger.addEventListener('click', function () {
        const item = this.closest('.accordion-item');
        const isOpen = item.classList.contains('open');

        // Close sibling accordions if within same container
        const parent = item.parentElement;
        parent.querySelectorAll('.accordion-item').forEach(sibling => {
          if (sibling !== item) {
            sibling.classList.remove('open');
            const panel = sibling.querySelector('.accordion-panel');
            if (panel) panel.style.maxHeight = null;
          }
        });

        if (isOpen) {
          item.classList.remove('open');
          const panel = item.querySelector('.accordion-panel');
          if (panel) panel.style.maxHeight = null;
        } else {
          item.classList.add('open');
          const panel = item.querySelector('.accordion-panel');
          if (panel) panel.style.maxHeight = panel.scrollHeight + 'px';
        }
      });
    });

    // FAQ Accordion
    document.querySelectorAll('.faq-question-btn').forEach(btn => {
      btn.addEventListener('click', function () {
        const item = this.closest('.faq-item');
        const isOpen = item.classList.contains('open');

        document.querySelectorAll('.faq-item').forEach(other => {
          if (other !== item) {
            other.classList.remove('open');
            const panel = other.querySelector('.faq-answer-panel');
            if (panel) panel.style.maxHeight = null;
          }
        });

        if (isOpen) {
          item.classList.remove('open');
          const panel = item.querySelector('.faq-answer-panel');
          if (panel) panel.style.maxHeight = null;
        } else {
          item.classList.add('open');
          const panel = item.querySelector('.faq-answer-panel');
          if (panel) panel.style.maxHeight = panel.scrollHeight + 'px';
        }
      });
    });
  }

  // --- Cart Helpers ---
  function addToCart(item) {
    const existingIndex = state.cart.findIndex(i =>
      i.id === item.id &&
      i.shape === item.shape &&
      i.size === item.size &&
      i.finish === item.finish
    );

    if (existingIndex > -1) {
      state.cart[existingIndex].quantity += item.quantity;
    } else {
      state.cart.push(item);
    }

    saveCart();
  }

  function quickAddToCart(productId) {
    const prod = PRODUCTS.find(p => p.id === productId);
    if (!prod) return;

    addToCart({
      id: prod.id,
      name: prod.name,
      price: prod.price,
      image: prod.image,
      shape: `${prod.defaultShape} (Medium)`,
      size: 'M',
      finish: prod.defaultFinish,
      quantity: 1
    });

    showToast(`Added ${prod.name} to your bag!`);
    openCartDrawer();
  }

  function updateCartQty(index, change) {
    if (!state.cart[index]) return;
    state.cart[index].quantity += change;
    if (state.cart[index].quantity <= 0) {
      state.cart.splice(index, 1);
      showToast('Item removed from bag');
    }
    saveCart();
  }

  function removeCartItem(index) {
    if (state.cart[index]) {
      const removed = state.cart.splice(index, 1);
      showToast(`Removed ${removed[0].name}`);
      saveCart();
    }
  }

  // --- Coupon Logic ---
  function applyCoupon() {
    const input = document.getElementById('cartCouponInput');
    if (!input) return;
    const code = input.value.trim().toUpperCase();

    if (code === 'AURA10') {
      state.appliedCoupon = 'AURA10';
      localStorage.setItem('nailaura_coupon', 'AURA10');
      showToast('✨ Promo code AURA10 applied: 10% OFF!');
      renderCartDrawer();
    } else if (code === '') {
      showToast('Please enter a coupon code', '⚠️');
    } else {
      showToast('Invalid coupon code. Try AURA10', '⚠️');
    }
  }

  function removeCoupon() {
    state.appliedCoupon = null;
    localStorage.removeItem('nailaura_coupon');
    showToast('Coupon removed');
    renderCartDrawer();
  }

  // --- Wishlist Helpers ---
  function toggleWishlist(productId) {
    const index = state.wishlist.indexOf(productId);
    const prod = PRODUCTS.find(p => p.id === productId);
    const name = prod ? prod.name : 'Design';

    if (index > -1) {
      state.wishlist.splice(index, 1);
      showToast(`Removed ${name} from Wishlist`, '♡');
    } else {
      state.wishlist.push(productId);
      showToast(`Saved ${name} to Wishlist!`, '💖');
    }

    saveWishlist();
  }

  // --- Quick View Modal ---
  function openQuickView(productId) {
    const prod = PRODUCTS.find(p => p.id === productId);
    if (!prod) return;

    const modal = document.getElementById('quickViewModal');
    const container = document.getElementById('quickViewModalContent');
    if (!modal || !container) return;

    container.innerHTML = `
      <div class="quick-view-grid">
        <div class="quick-view-img">
          <img src="${prod.image}" alt="${prod.name}">
        </div>
        <div style="display: flex; flex-direction: column;">
          <span class="product-category-tag">${prod.categoryLabel}</span>
          <h3 style="font-family: var(--font-serif); font-size: 1.8rem; margin: 0.25rem 0 0.5rem 0;">${prod.name}</h3>
          <div class="product-rating" style="margin-bottom: 0.75rem;">
            <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
            <span class="review-count">(${prod.reviewsCount} verified reviews)</span>
          </div>
          <p style="font-size: 1.4rem; font-weight: 700; color: var(--color-charcoal); margin-bottom: 1rem;">
            ${formatINR(prod.price)}
          </p>
          <p style="font-size: 0.92rem; color: var(--color-charcoal-muted); line-height: 1.6; margin-bottom: 1.5rem;">
            ${prod.description}
          </p>

          <div class="option-group" style="margin-bottom: 1rem;">
            <label style="font-size: 0.82rem; font-weight: 600; display: block; margin-bottom: 0.4rem;">Select Nail Shape:</label>
            <div class="pills-selector" id="qvShapes">
              ${prod.shapes.map((s, idx) => `
                <button class="pill-option ${idx === 0 ? 'active' : ''}" data-val="${s}">${s}</button>
              `).join('')}
            </div>
          </div>

          <div class="option-group" style="margin-bottom: 1.5rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
              <label style="font-size: 0.82rem; font-weight: 600;">Select Sizing:</label>
              <a href="#size-guide" class="size-guide-trigger" onclick="window.NailAuraApp.closeModal('quickViewModal')">Size Guide</a>
            </div>
            <div class="pills-selector" id="qvSizes">
              <button class="pill-option" data-val="XS">XS</button>
              <button class="pill-option" data-val="S">S</button>
              <button class="pill-option active" data-val="M">M</button>
              <button class="pill-option" data-val="L">L</button>
              <button class="pill-option" data-val="Custom">Custom</button>
            </div>
          </div>

          <div style="display: flex; gap: 0.75rem; margin-top: auto;">
            <button class="btn btn-primary" style="flex-grow: 1;" onclick="window.NailAuraApp.addQuickViewToCart('${prod.id}')">
              Add to Bag • ${formatINR(prod.price)}
            </button>
            <button class="btn-wishlist ${state.wishlist.includes(prod.id) ? 'active' : ''}"
                    style="position: static; width: 44px; height: 44px;"
                    onclick="window.NailAuraApp.toggleWishlist('${prod.id}')">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="${state.wishlist.includes(prod.id) ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `;

    // Pill selectors inside Quick View
    container.querySelectorAll('#qvShapes .pill-option').forEach(btn => {
      btn.addEventListener('click', function () {
        container.querySelectorAll('#qvShapes .pill-option').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
      });
    });

    container.querySelectorAll('#qvSizes .pill-option').forEach(btn => {
      btn.addEventListener('click', function () {
        container.querySelectorAll('#qvSizes .pill-option').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
      });
    });

    openModal('quickViewModal');
  }

  function addQuickViewToCart(productId) {
    const prod = PRODUCTS.find(p => p.id === productId);
    if (!prod) return;

    const shape = document.querySelector('#qvShapes .pill-option.active')?.getAttribute('data-val') || prod.defaultShape;
    const size = document.querySelector('#qvSizes .pill-option.active')?.getAttribute('data-val') || 'M';

    addToCart({
      id: prod.id,
      name: prod.name,
      price: prod.price,
      image: prod.image,
      shape: `${shape} (Medium)`,
      size: size,
      finish: prod.defaultFinish,
      quantity: 1
    });

    closeModal('quickViewModal');
    showToast(`Added ${prod.name} to your bag!`);
    openCartDrawer();
  }

  // --- Modal Utilities ---
  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  // --- Checkout Modal Experience ---
  function openCheckoutModal() {
    closeDrawers();
    const modal = document.getElementById('checkoutModal');
    if (!modal) return;

    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const freeShipping = subtotal >= state.freeShippingThreshold;
    let discount = 0;
    if (state.appliedCoupon === 'AURA10') discount = Math.round(subtotal * 0.10);
    const shipping = freeShipping ? 0 : state.shippingFee;
    const total = subtotal - discount + shipping;

    const summaryBox = document.getElementById('checkoutOrderSummary');
    if (summaryBox) {
      summaryBox.innerHTML = `
        <div style="background: var(--color-white); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid rgba(200,94,111,0.15); margin-bottom: 1.5rem;">
          <h4 style="font-family: var(--font-serif); font-size: 1.15rem; margin-bottom: 0.75rem;">Order Review (${state.cart.length} item${state.cart.length > 1 ? 's' : ''})</h4>
          <div style="max-height: 180px; overflow-y: auto; margin-bottom: 1rem; display: flex; flex-direction: column; gap: 0.5rem;">
            ${state.cart.map(i => `
              <div style="display: flex; justify-content: space-between; font-size: 0.85rem; border-bottom: 1px solid #f0e8e6; padding-bottom: 0.35rem;">
                <span>${i.name} (${i.shape}, ${i.size}) × ${i.quantity}</span>
                <span style="font-weight: 600;">${formatINR(i.price * i.quantity)}</span>
              </div>
            `).join('')}
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.9rem; color: var(--color-charcoal-muted); margin-bottom: 0.3rem;">
            <span>Subtotal:</span>
            <span>${formatINR(subtotal)}</span>
          </div>
          ${discount > 0 ? `
            <div style="display: flex; justify-content: space-between; font-size: 0.9rem; color: var(--color-rose-dark); margin-bottom: 0.3rem;">
              <span>Promo Discount (AURA10):</span>
              <span>−${formatINR(discount)}</span>
            </div>
          ` : ''}
          <div style="display: flex; justify-content: space-between; font-size: 0.9rem; color: var(--color-charcoal-muted); margin-bottom: 0.5rem;">
            <span>Express Pan-India Shipping:</span>
            <span>${freeShipping ? '<strong style="color: var(--color-success)">FREE</strong>' : formatINR(shipping)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: 700; color: var(--color-charcoal); border-top: 1px dashed rgba(200,94,111,0.25); padding-top: 0.5rem;">
            <span>Grand Total:</span>
            <span style="color: var(--color-rose-dark);">${formatINR(total)}</span>
          </div>
        </div>
      `;
    }

    openModal('checkoutModal');
  }

  function handleCheckoutSubmit(e) {
    e.preventDefault();
    const btn = document.getElementById('placeOrderSubmitBtn');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '✨ Processing Your Order...';
    }

    setTimeout(() => {
      const orderId = 'NA-' + Math.floor(100000 + Math.random() * 900000);
      const modalContent = document.getElementById('checkoutModalBody');
      if (modalContent) {
        modalContent.innerHTML = `
          <div style="text-align: center; padding: 3rem 1.5rem;">
            <div style="font-size: 3.5rem; margin-bottom: 1rem; animation: pulse-sparkle 1.5s infinite;">✨</div>
            <h3 style="font-family: var(--font-serif); font-size: 2rem; color: var(--color-charcoal); margin-bottom: 0.5rem;">
              Thank You for Your Order!
            </h3>
            <p style="font-size: 1.05rem; color: var(--color-rose-dark); font-weight: 600; margin-bottom: 1.5rem;">
              Order Reference #${orderId}
            </p>
            <p style="font-size: 0.95rem; color: var(--color-charcoal-muted); max-width: 480px; margin: 0 auto 2rem auto; line-height: 1.7;">
              Your order confirmation and tracking link have been dispatched to your email and WhatsApp. Abha is preparing your bespoke nail kit with love and artistry!
            </p>
            <div style="background: var(--color-blush-subtle); padding: 1.25rem; border-radius: var(--radius-lg); max-width: 420px; margin: 0 auto 2rem auto; text-align: left; font-size: 0.88rem; line-height: 1.6;">
              <p>📦 <strong>Fulfillment Status:</strong> Queued for Handcrafting</p>
              <p>⏱️ <strong>Estimated Dispatch:</strong> Within 2-3 business days</p>
              <p>💬 <strong>Support:</strong> WhatsApp +91 98765 43210 with order reference</p>
            </div>
            <button class="btn btn-primary btn-lg" onclick="window.NailAuraApp.finishOrder()">
              Continue Browsing
            </button>
          </div>
        `;
      }

      // Empty cart
      state.cart = [];
      saveCart();
      showToast('Order confirmed! Check your email for updates 💌');
    }, 1200);
  }

  function finishOrder() {
    closeModal('checkoutModal');
    location.reload();
  }

  // --- Search Dialog Modal ---
  function openSearchModal() {
    const modal = document.getElementById('searchModal');
    if (modal) {
      openModal('searchModal');
      const input = document.getElementById('liveSearchInput');
      if (input) {
        input.value = '';
        setTimeout(() => input.focus(), 150);
        renderSearchResults('');
      }
    }
  }

  function renderSearchResults(query) {
    const resultsContainer = document.getElementById('liveSearchResults');
    if (!resultsContainer) return;

    const q = query.trim().toLowerCase();
    if (!q) {
      resultsContainer.innerHTML = `
        <div style="text-align: center; padding: 2rem; color: var(--color-charcoal-light); font-size: 0.9rem;">
          Type to search our hand-crafted nail designs, shapes, or finishes...
        </div>
      `;
      return;
    }

    const matches = PRODUCTS.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.categoryLabel.toLowerCase().includes(q) ||
      p.shapes.some(s => s.toLowerCase().includes(q))
    );

    if (matches.length === 0) {
      resultsContainer.innerHTML = `
        <div style="text-align: center; padding: 2rem; color: var(--color-charcoal-muted); font-size: 0.95rem;">
          No matching designs found for "<strong>${query}</strong>".
        </div>
      `;
      return;
    }

    resultsContainer.innerHTML = matches.map(prod => `
      <div style="display: flex; align-items: center; gap: 1rem; padding: 0.85rem; border-bottom: 1px solid rgba(200,94,111,0.1); cursor: pointer; border-radius: var(--radius-md); transition: background 0.2s;"
           onmouseover="this.style.background='var(--color-blush-subtle)'"
           onmouseout="this.style.background='transparent'"
           onclick="window.NailAuraApp.selectSearchResult('${prod.id}')">
        <img src="${prod.image}" alt="${prod.name}" style="width: 52px; height: 52px; object-fit: cover; border-radius: 8px;">
        <div style="flex-grow: 1;">
          <h5 style="font-size: 0.95rem; font-weight: 600; color: var(--color-charcoal); margin: 0;">${prod.name}</h5>
          <span style="font-size: 0.78rem; color: var(--color-rose);">${prod.categoryLabel}</span>
        </div>
        <span style="font-weight: 700; color: var(--color-charcoal); font-size: 0.95rem;">${formatINR(prod.price)}</span>
      </div>
    `).join('');
  }

  function selectSearchResult(productId) {
    closeModal('searchModal');
    openQuickView(productId);
  }

  // --- Contact Form Handler ---
  function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = 'Sending Message...';
      }

      setTimeout(() => {
        showToast('Thank you! Your message has been sent to Abha ♡', '💌');
        form.reset();
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = 'Send Message ✨';
        }
      }, 800);
    });
  }

  // --- Newsletter Form Handler ---
  function initNewsletterForm() {
    const form = document.getElementById('newsletterForm');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const emailInput = form.querySelector('input[type="email"]');
      if (emailInput && emailInput.value) {
        showToast('Welcome to the NailAura family! Check your inbox for 10% off ✨', '💌');
        form.reset();
      }
    });
  }

  // --- Sticky Header Scroll Effect & Navigation ---
  function initNavigation() {
    const header = document.querySelector('.site-header');
    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        header?.classList.add('scrolled');
      } else {
        header?.classList.remove('scrolled');
      }
    });

    // Mobile Hamburger Toggle
    const mobileBtn = document.getElementById('mobileMenuToggle');
    if (mobileBtn) {
      mobileBtn.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        const mobileMenu = document.getElementById('mobileNavDrawer');
        if (mobileMenu && mobileMenu.classList.contains('open')) {
          closeMobileMenu();
        } else {
          openMobileMenu();
        }
      };
    }

    // Filter Buttons in Shop
    document.querySelectorAll('.filter-pill').forEach(pill => {
      pill.addEventListener('click', function () {
        document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
        this.classList.add('active');
        state.activeFilter = this.getAttribute('data-filter') || 'all';
        renderProductsGrid();
      });
    });

    // Sort Dropdown
    const sortSelect = document.getElementById('shopSortSelect');
    if (sortSelect) {
      sortSelect.addEventListener('change', function () {
        state.sortBy = this.value;
        renderProductsGrid();
      });
    }

    // Shop Live Filter Search
    const searchInput = document.getElementById('shopSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', function () {
        state.searchQuery = this.value;
        renderProductsGrid();
      });
    }
  }

  // Set filter programmatically from category cards
  function setCategoryFilter(categoryKey) {
    const pill = document.querySelector(`.filter-pill[data-filter="${categoryKey}"]`);
    if (pill) {
      document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      state.activeFilter = categoryKey;
      renderProductsGrid();
      const shopEl = document.getElementById('shop');
      if (shopEl) shopEl.scrollIntoView({ behavior: 'smooth' });
    }
  }

  function resetFilters() {
    const allPill = document.querySelector('.filter-pill[data-filter="all"]');
    if (allPill) {
      document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
      allPill.classList.add('active');
    }
    state.activeFilter = 'all';
    state.searchQuery = '';
    const searchInput = document.getElementById('shopSearchInput');
    if (searchInput) searchInput.value = '';
    renderProductsGrid();
  }

  // --- DOM Ready Initializer ---
  document.addEventListener('DOMContentLoaded', () => {
    updateHeaderCounters();
    renderProductsGrid();
    renderCartDrawer();
    initFeaturedProductSection();
    initAccordions();
    initSizeCalculator();
    initNavigation();
    initContactForm();
    initNewsletterForm();

    // Check URL params for category filter (e.g. shop.html?filter=french-tips)
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const filterParam = urlParams.get('filter');
      if (filterParam) {
        setCategoryFilter(filterParam);
      }
    } catch (e) {
      console.warn('URL param parse error:', e);
    }

    // Live search listener
    const liveSearchInput = document.getElementById('liveSearchInput');
    if (liveSearchInput) {
      liveSearchInput.addEventListener('input', function () {
        renderSearchResults(this.value);
      });
    }

    // Backdrop click closes drawers & modals
    const backdrop = document.getElementById('drawerBackdrop');
    if (backdrop) {
      backdrop.addEventListener('click', closeDrawers);
    }

    const modalBackdrops = document.querySelectorAll('.modal-backdrop');
    modalBackdrops.forEach(m => {
      m.addEventListener('click', function (e) {
        if (e.target === this) {
          this.classList.remove('active');
          document.body.style.overflow = '';
        }
      });
    });

    console.log('✨ NailAura by Abha initialized successfully.');
  });

  // --- Expose Public API to Window ---
  window.NailAuraApp = {
    openMobileMenu,
    closeMobileMenu,
    openCartDrawer,
    closeDrawers,
    openWishlistDrawer,
    quickAddToCart,
    updateCartQty,
    removeCartItem,
    applyCoupon,
    removeCoupon,
    toggleWishlist,
    openQuickView,
    addQuickViewToCart,
    openModal,
    closeModal,
    openCheckoutModal,
    handleCheckoutSubmit,
    finishOrder,
    openSearchModal,
    selectSearchResult,
    setCategoryFilter,
    resetFilters
  };

})();
